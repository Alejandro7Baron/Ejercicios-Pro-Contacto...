# How to run
Para ejecutar el programa es necesario inciar el servidor
En la terminal de VS Code teclear: node mostrarPersonas
Lo que inciará el sevidor local (3000), una vez iniciado mostrará la url en la terminal,
sólo click para poder ver el archivo en su navegador.
Se abrirá por supuesto el archivo HTML con el formulario pidiendo los datos, desafortudamente no lo terminé:(
    Aún asi están enlazados, no funciona el post
    Gran intento de mi parte, como les dijé.. No había hecho esto anteriormente haha
    :)